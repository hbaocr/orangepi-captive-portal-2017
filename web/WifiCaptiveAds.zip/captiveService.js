/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
"use strict";
var bash_cmd = require('./sudoBashCmd');
var arp = require('arp');

var captiveService = function (sudo_pass = 'orangepi') {
    this.map_devices = new Map();
    this.sudo_pass = sudo_pass;

};
/*default 12h valid periode*/
captiveService.prototype.addNewDevToConnectedList = function (mac_key, ip_val,remote_info='', period_valid_ms = 43200000) {
    //if the list is already created for the "key", then uses it
    //else creates new list for the "key" to store multiple values in it.
    let ms_start = new Date().getTime();
    let cmd = new bash_cmd(this.sudo_pass);
    let val = {'ip': ip_val, 'ms_start': ms_start,'remote_info':remote_info, 'period_valid_ms': period_valid_ms};
    this.map_devices.set(mac_key, val);
    cmd.iptables_new_bypass_rule(ip_val, mac_key);
};

captiveService.prototype.removeDevToConnectedList = function (mac_key, ip_val) {
//    console.log(this);
    let cmd = new bash_cmd(this.sudo_pass);
    cmd.iptables_remove_bypass_rule(ip_val, mac_key);//bypass rule and clearContrack info 
   
};

captiveService.prototype.periodRun = function (period_ms) {
    var devicelist = this.map_devices;
    var removeDevToConnectedList = this.removeDevToConnectedList.bind(captiveService);//bind to captiveService ---> this giu lai context cua captiveClass
    setInterval(function () {
        console.log('****************************');
        for (let [mac, info] of devicelist.entries()) {
            console.log(`mac = ${mac}  :  info = ${info.ip}`);
            let ms = new Date().getTime();
            let end_ms = info.ms_start + info.period_valid_ms;
            if (ms > end_ms)
            {
                //remove
                console.log(`remove mac = ${mac}  :  info = ${info.ip}`);
                devicelist.delete(mac);
                removeDevToConnectedList(mac, info.ip);
            }
        }
    }, period_ms);
};


module.exports = captiveService;